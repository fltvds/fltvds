from turtle import *

for i in range(5):
    for j in range(5):
        down()
        left(30)
        forward(10)
        right(60)
        forward(10)
        left(60)
        forward(10)
        right(60)
        forward(10)
        
        up()
        left(30)
        forward(40)
    right(90)
    forward(40)
    left(90)
    back(373)
    
